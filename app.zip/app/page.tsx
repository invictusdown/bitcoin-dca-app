import Home from './home'

export default function Page() {
  return <Home />
}